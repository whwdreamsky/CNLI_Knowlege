chmod +x /home/hwwang/workplace/project/DAM/src/train.py  
CUDA_VISIBLE_DEVICES="" python2 /home/hwwang/workplace/project/DAM/src/train.py --model lstm -u 300 -e 20 -aw 0  --save /home/hwwang/workplace/project/DAM/model_weights/DAM_mlp_3/ 1> /home/hwwang/workplace/project/DAM/log/log_snli_mlp_with_break_0416.log 2> //home/hwwang/workplace/project/DAM/log/log_snli_mlp_with_break_0416.txt &
